﻿using Microsoft.AspNetCore.Mvc;
using OkulProjesi.data;
using OkulProjesi.Models;
using System.Diagnostics;

namespace OkulProjesi.Controllers
{
    public class OgrenciController : Controller
    {
        private readonly ILogger<OgrenciController> _logger;
        private OkulİdaresiContext _okulİdaresiContext;

        public OgrenciController(ILogger<OgrenciController> logger, OkulİdaresiContext okulİdaresiContext)
        {
            _logger = logger;
            _okulİdaresiContext = okulİdaresiContext;
        }

        public IActionResult Index()
        {
            OgrenciModel ogrenciModel = new OgrenciModel();
            ogrenciModel.OgrenciList = new List<Ogrenci>();
            var data = _okulİdaresiContext.OgrenciTables.ToList();
            foreach (var item in data)
            {
                ogrenciModel.OgrenciList.Add(new Ogrenci
                {
                    Id = item.Id,
                    AdSoyad = item.AdSoyad,
                    KayitTarih = item.KayitTarih,
                    OgrenciNo = item.OgrenciNo,
                    Dtarih = item.Dtarih,
                    Bolum = item.Bolum

                });
            }

            return View(ogrenciModel);
        }
             
        [HttpGet]
        public IActionResult Kaydet()
        {
            Ogrenci ogrenci = new Ogrenci();
            return View(ogrenci);
        }
        [HttpPost]
        public IActionResult Kaydet(Ogrenci ogrenci)
        {
            try
            {
                var ogrenciveri = new OgrenciTable()
                {
                    Id = ogrenci.Id,
                    AdSoyad = ogrenci.AdSoyad,
                    KayitTarih = ogrenci.KayitTarih,
                    OgrenciNo = ogrenci.OgrenciNo,
                    Dtarih = ogrenci.Dtarih,
                    Bolum = ogrenci.Bolum
                };
                _okulİdaresiContext.OgrenciTables.Add(ogrenciveri);
                _okulİdaresiContext.SaveChanges();
                TempData["SaveStatus"] = 1;
            }
            catch (Exception ex)
            {
                TempData["SaveStatus"] = 0;
            }
            return RedirectToAction("Index", "Ogrenci");
        }
        [HttpGet]
        public IActionResult Update(int Id = 0)
        {
            Ogrenci ogrenci = new Ogrenci();
            var data = _okulİdaresiContext.OgrenciTables.Where(m => m.Id == Id).FirstOrDefault();
            if (data != null)
            {
                ogrenci.Id = data.Id;
                ogrenci.AdSoyad = data.AdSoyad;
                ogrenci.KayitTarih = data.KayitTarih;
                ogrenci.OgrenciNo = data.OgrenciNo;
                ogrenci.Dtarih = data.Dtarih;
                ogrenci.Bolum = data.Bolum;
            }
            return View(ogrenci);
        }
        [HttpPost]
        public IActionResult Update(Ogrenci ogrenci)
        {
            try
            {
                var data = _okulİdaresiContext.OgrenciTables.Where(m => m.Id == ogrenci.Id).FirstOrDefault();
                data.AdSoyad = ogrenci.AdSoyad;
                data.KayitTarih = ogrenci.KayitTarih;
                data.OgrenciNo = ogrenci.OgrenciNo;
                data.Dtarih = ogrenci.Dtarih;
                data.Bolum = ogrenci.Bolum;
                _okulİdaresiContext.SaveChanges();
                TempData["UpdateStatus"] = 1;
            }
            catch
            {
                TempData["UpdateStatus"] = 0;
            }
            return RedirectToAction("Index", "Ogrenci");
        }
        [HttpGet]
        public IActionResult Delete(int Id = 0)
        {
            try
            {
                var data = _okulİdaresiContext.OgrenciTables.Where(m => m.Id == Id).FirstOrDefault();
                if (data != null)
                {
                    _okulİdaresiContext.OgrenciTables.Remove(data);
                    _okulİdaresiContext.SaveChanges();
                }
                TempData["DeleteStatus"] = 1;

            }
            catch
            {
                TempData["DeleteStatus"] = 0;
            }
            return RedirectToAction("Index", "Ogrenci");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}