﻿using System;
using System.Collections.Generic;

namespace OkulProjesi.data
{
    public partial class OkulYonetimTable
    {
        public OkulYonetimTable()
        {
            DersTables = new HashSet<DersTable>();
        }

        public int Id { get; set; }
        public string? AdSoyad { get; set; }
        public string? Gorevi { get; set; }
        public int? YonetimTip { get; set; }

        public virtual ICollection<DersTable> DersTables { get; set; }
    }
}
