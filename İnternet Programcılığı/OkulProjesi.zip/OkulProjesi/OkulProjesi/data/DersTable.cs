﻿using System;
using System.Collections.Generic;

namespace OkulProjesi.data
{
    public partial class DersTable
    {
        public DersTable()
        {
            OgrenciDersTables = new HashSet<OgrenciDersTable>();
        }

        public int Id { get; set; }
        public string? Ad { get; set; }
        public double? Kredisi { get; set; }
        public int? OkulYonetimId { get; set; }

        public virtual OkulYonetimTable? OkulYonetim { get; set; }
        public virtual ICollection<OgrenciDersTable> OgrenciDersTables { get; set; }
    }
}
