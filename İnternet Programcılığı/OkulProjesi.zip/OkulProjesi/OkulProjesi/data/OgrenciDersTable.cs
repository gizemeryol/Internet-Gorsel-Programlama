﻿using System;
using System.Collections.Generic;

namespace OkulProjesi.data
{
    public partial class OgrenciDersTable
    {
        public int Id { get; set; }
        public int? DersId { get; set; }
        public int? OgrenciId { get; set; }

        public virtual DersTable? Ders { get; set; }
        public virtual OgrenciTable? Ogrenci { get; set; }
    }
}
