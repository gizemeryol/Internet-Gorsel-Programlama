﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace OkulProjesi.data
{
    public partial class OkulİdaresiContext : DbContext
    {
        public OkulİdaresiContext()
        {
        }

        public OkulİdaresiContext(DbContextOptions<OkulİdaresiContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DersTable> DersTables { get; set; } = null!;
        public virtual DbSet<OgrenciDersTable> OgrenciDersTables { get; set; } = null!;
        public virtual DbSet<OgrenciTable> OgrenciTables { get; set; } = null!;
        public virtual DbSet<OkulYonetimTable> OkulYonetimTables { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=Okulİdaresi;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DersTable>(entity =>
            {
                entity.ToTable("DersTable");

                entity.Property(e => e.Ad).HasMaxLength(50);

                entity.HasOne(d => d.OkulYonetim)
                    .WithMany(p => p.DersTables)
                    .HasForeignKey(d => d.OkulYonetimId)
                    .HasConstraintName("FK_DersTable_OkulYonetimTable");
            });

            modelBuilder.Entity<OgrenciDersTable>(entity =>
            {
                entity.ToTable("OgrenciDersTable");

                entity.HasOne(d => d.Ders)
                    .WithMany(p => p.OgrenciDersTables)
                    .HasForeignKey(d => d.DersId)
                    .HasConstraintName("FK_OgrenciDersTable_DersTable");

                entity.HasOne(d => d.Ogrenci)
                    .WithMany(p => p.OgrenciDersTables)
                    .HasForeignKey(d => d.OgrenciId)
                    .HasConstraintName("FK_OgrenciDersTable_OgrenciTable");
            });

            modelBuilder.Entity<OgrenciTable>(entity =>
            {
                entity.ToTable("OgrenciTable");

                entity.Property(e => e.AdSoyad).HasMaxLength(50);

                entity.Property(e => e.Bolum).HasMaxLength(50);

                entity.Property(e => e.Dtarih)
                    .HasColumnType("date")
                    .HasColumnName("DTarih");

                entity.Property(e => e.KayitTarih).HasColumnType("date");
            });

            modelBuilder.Entity<OkulYonetimTable>(entity =>
            {
                entity.ToTable("OkulYonetimTable");

                entity.Property(e => e.AdSoyad).HasMaxLength(50);

                entity.Property(e => e.Gorevi).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
