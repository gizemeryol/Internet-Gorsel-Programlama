﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Okulİdaresi
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        OkulİdaresiEntities db;
        void listele()
        {
            dataGridView1.DataSource = (from x in db.DersTable
                                        select new
                                        {
                                            x.Id,
                                            x.Ad,
                                            x.Kredisi,
                                            x.OkulYonetimId

                                        }).ToList();


            var derslist = db.DersTable.ToList();
        }
        private void Ders_Load(object sender, EventArgs e)
        {
            listele();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             DersTable ekle = new DersTable();
            ekle.Ad = txtad.Text;
            ekle.Kredisi = Convert.ToInt32(txtkredi.Text);
            ekle.OkulYonetimId = Convert.ToInt32(txtokulyg.Text);
            db.DersTable.Add(ekle);
            db.SaveChanges();
            MessageBox.Show("İşlem başarılı");
            listele();

            txtid.Clear();
            txtad.Clear();
            txtkredi.Clear();
            txtokulyg.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int DersId = Convert.ToInt32(txtid.Text);

            var dersbul = db.DersTable.Find(DersId);
            db.DersTable.Remove(dersbul);
            db.SaveChanges();
            MessageBox.Show("Öğrenci Kayıdı Silindi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int DersId = Convert.ToInt32(txtid.Text);

            var guncelle = db.DersTable.Find(DersId);
            guncelle.Ad = txtad.Text;
            guncelle.Kredisi = Convert.ToInt32(txtkredi.Text);
            guncelle.OkulYonetimId = Convert.ToInt32(txtokulyg.Text);
            db.SaveChanges();
            MessageBox.Show("Öğrenci Kayıdı Güncellendi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string aranan = textBox5.Text;
            var degerler = from item in db.DersTable
                           where item.Ad.Contains(aranan)
                           // where item.Kredisi.ToString().Contains(aranan)
                           //  where item.OkulYonetimId.ToString().Contains(aranan)
                           select item;
            dataGridView1.DataSource = degerler.ToList();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;
            txtid.Text = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            txtad.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            txtkredi.Text = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            txtokulyg.Text = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
        }
    }
}
