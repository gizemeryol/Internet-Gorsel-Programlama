﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Okulİdaresi
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        OkulİdaresiEntities db;
        void listele()
        {
            db = new OkulİdaresiEntities();
            dataGridView1.DataSource = (from x in db.OkulYonetimTable
                                        select new
                                        {
                                            x.Id,
                                            x.AdSoyad,
                                            x.Gorevi,
                                            x.YonetimTip,
                                        }).ToList();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            OkulYonetimTable ekle = new OkulYonetimTable();
            ekle.AdSoyad = txtadsoyad.Text;
            ekle.Gorevi = txtgorev.Text;
            ekle.YonetimTip = Convert.ToInt32(txtyonetim.Text);
            db.OkulYonetimTable.Add(ekle);
            db.SaveChanges();
            MessageBox.Show("İşlem başarılı");
            listele();

            txtid.Clear();
            txtadsoyad.Clear();
            txtgorev.Clear();
            txtyonetim.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int OkulYonetimId = Convert.ToInt32(txtid.Text);

            var OkulYonetimbul = db.OkulYonetimTable.Find(OkulYonetimId);
            db.OkulYonetimTable.Remove(OkulYonetimbul);
            db.SaveChanges();
            MessageBox.Show("Okul Yonetim Kayıdı Silindi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int OkulYonetimId = Convert.ToInt32(txtid.Text);

            var guncelle = db.OkulYonetimTable.Find(OkulYonetimId);
            guncelle.AdSoyad = txtadsoyad.Text;
            guncelle.Gorevi = txtgorev.Text;
            guncelle.YonetimTip = Convert.ToInt32(txtyonetim.Text);
            db.SaveChanges();
            MessageBox.Show("Okul Yonetim Kayıdı Güncellendi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;
            txtid.Text = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            txtadsoyad.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            txtgorev.Text = dataGridView1.Rows[secilen].Cells[5].Value.ToString();
            txtyonetim.Text = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
        }
        private void txtid_TextChanged(object sender, EventArgs e)
        {
            string aranan = txtid.Text;
            var degerler = from item in db.OgrenciTable
                           where item.AdSoyad.Contains(aranan)
                           select item;
            dataGridView1.DataSource = degerler.ToList();
        }
    }
}
