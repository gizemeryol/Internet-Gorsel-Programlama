﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Okulİdaresi
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        OkulİdaresiEntities db;

        void listele()
        {
            db = new OkulİdaresiEntities();
            dataGridView1.DataSource = (from x in db.OgrenciTable
                                        select new
                                        {
                                            x.Id,
                                            x.AdSoyad,
                                            x.KayitTarih,
                                            x.OgrenciNo,
                                            x.DTarih,
                                            x.Bolum,
                                        }).ToList();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            OgrenciTable ekle = new OgrenciTable();
            ekle.AdSoyad = textBox2.Text;
            ekle.KayitTarih = DateTime.Now;
            ekle.OgrenciNo = Convert.ToInt32(textBox4.Text);
            ekle.DTarih = DateTime.Now;
            ekle.Bolum = textBox6.Text;
            db.OgrenciTable.Add(ekle);
            db.SaveChanges();
            MessageBox.Show("İşlem başarılı");
            listele();

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();

        }
        private void Ogrenci_Load_1(object sender, EventArgs e)
        {
            listele();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int OgrenciId = Convert.ToInt32(textBox1.Text);

            var ogrencibul = db.OgrenciTable.Find(OgrenciId);
            db.OgrenciTable.Remove(ogrencibul);
            db.SaveChanges();
            MessageBox.Show("Öğrenci Kayıdı Silindi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
            int Id = Convert.ToInt32(textBox1.Text); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var guncelle = db.OgrenciTable.Find();
            guncelle.AdSoyad = textBox2.Text;
            guncelle.KayitTarih = DateTime.Now;
            guncelle.OgrenciNo = Convert.ToInt32(textBox4.Text);
            guncelle.DTarih = DateTime.Now;
            guncelle.Bolum = textBox5.Text;
            db.SaveChanges();
            MessageBox.Show("Öğrenci Kayıdı Güncellendi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;

            textBox1.Text = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.Rows[secilen].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.Rows[secilen].Cells[4].Value.ToString();
        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string aranan = textBox6.Text;
            var degerler = from item in db.OgrenciTable
                           where item.AdSoyad.Contains(aranan)
                           // where item.KayitTarih.ToString().Contains(aranan)
                           // where item.OgrenciNo.ToString().Contains(aranan)
                           // where item.DTarih.ToString().Contains(aranan)
                           // where item.Bolum.Contains(aranan)
                           select item;
            dataGridView1.DataSource = degerler.ToList();
        }

    }
}
