﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Okulİdaresi
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        OkulİdaresiEntities db;
        void listele()
        {
            db = new OkulİdaresiEntities();
            dataGridView1.DataSource = (from x in db.OgrenciDersTable
                                        select new
                                        {
                                            x.Id,
                                            x.DersTable.Ad,
                                            x.OgrenciTable.AdSoyad,
                                        }).ToList();
        }
        private void OgrenciDers_Load(object sender, EventArgs e)
        {
            listele();
            var ogrenciler = (from x in db.OgrenciTable
                              select new
                              {
                                  x.Id,
                                  x.AdSoyad

                              }).ToList();

            comboBox2.ValueMember = "Id";
            comboBox2.DisplayMember = "AdSoyad";
            comboBox2.DataSource = ogrenciler; listele();


            var dersler = (from x in db.DersTable
                           select new
                           {
                               x.Id,
                               x.Ad

                           }).ToList();

            comboBox1.ValueMember = "Id";
            comboBox1.DisplayMember = "Ad";
            comboBox1.DataSource = dersler; listele();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            OgrenciDersTable ekle = new OgrenciDersTable();
            ekle.DersId = Convert.ToInt16(comboBox1.SelectedValue);
            ekle.OgrenciId = Convert.ToInt16(comboBox2.SelectedValue);
            db.OgrenciDersTable.Add(ekle);
            db.SaveChanges();
            MessageBox.Show("Öğrenciye Ders Ataması Yapıldı.", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int OkulYonetimId = Convert.ToInt32(txtid.Text);

            var OkulYonetimbul = db.OkulYonetimTable.Find(OkulYonetimId);
            db.OkulYonetimTable.Remove(OkulYonetimbul);
            db.SaveChanges();
            MessageBox.Show("Okul Yonetim Kayıdı Silindi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int DersID = Convert.ToInt32(txtid.Text);

            var guncelle = db.OgrenciDersTable.Find(DersID);
            guncelle.Id = Convert.ToInt32(txtid.Text);
            guncelle.DersId = Convert.ToInt32(comboBox1.Text);
            guncelle.OgrenciId = Convert.ToInt16(comboBox2.SelectedValue);
            db.SaveChanges();
            MessageBox.Show("Ders Kayıdı Güncellendi", "Sistem Mesajı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            listele();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilen = dataGridView1.SelectedCells[0].RowIndex;
            txtid.Text = dataGridView1.Rows[secilen].Cells[0].Value.ToString();
            comboBox1.Text = dataGridView1.Rows[secilen].Cells[1].Value.ToString();
            comboBox2.Text = dataGridView1.Rows[secilen].Cells[2].Value.ToString();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            string aranan = textBox4.Text;
            var degerler = from item in db.OgrenciDersTable
                           where item.DersId.ToString().Contains(aranan)
                           where item.OgrenciId.ToString().Contains(aranan)
                           select item;
            dataGridView1.DataSource = degerler.ToList();
        }
    }
}
